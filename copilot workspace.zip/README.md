# Copilot workspace

A calm, Microsoft inspired Copilot style workspace built as a portfolio project. It combines a conversational surface with a small Azure architecture panel so you can demonstrate how you think about solutions, not just how you code.

The assistant has a small animated character called Tanya who welcomes visitors, and there is a subtle note for reviewers that explains the intent of the demo.

## Tech stack

- React
- TypeScript
- Vite
- Framer Motion

## Run locally

```bash
npm install
npm run dev
```
