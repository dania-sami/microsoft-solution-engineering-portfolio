import React from "react";
import { motion } from "framer-motion";

type Role = "user" | "assistant";

interface Message {
  id: number;
  role: Role;
  content: string;
}

interface ArchitectureLayer {
  name: string;
  services: string;
  notes: string;
}

interface ArchitectureView {
  title: string;
  scenario: string;
  layers: ArchitectureLayer[];
}

type PersonaId = "solution" | "architect" | "pm" | "security";


type TabId = "conversations" | "usecases" | "architectures" | "playground";

const tabMeta: Record<
  TabId,
  {
    label: string;
    description: string;
    placeholder: string;
  }
> = {
  conversations: {
    label: "Conversations",
    description:
      "Ask anything about Azure, projects or interviews. This is the main view for dialogue.",
    placeholder:
      "Ask for an Azure architecture, project plan or interview help",
  },
  usecases: {
    label: "Use cases",
    description:
      "Explore scenarios where a focused Copilot assistant would help customers or internal teams.",
    placeholder: "Ask for a Copilot use case in a specific industry",
  },
  architectures: {
    label: "Architectures",
    description:
      "Focus on solution sketches. Mention Azure or architecture to refresh the panel on the right.",
    placeholder:
      "Ask for an Azure reference design for a workload or customer scenario",
  },
  playground: {
    label: "Playground",
    description:
      "Experiment freely with questions, copy variations and interview phrases.",
    placeholder: "Try any prompt. This space is for experiments.",
  },
};
const personas: { id: PersonaId; label: string; subtitle: string }[] = [
  {
    id: "solution",
    label: "Solution Engineer",
    subtitle: "Customer focused",
  },
  {
    id: "architect",
    label: "Cloud Architect",
    subtitle: "End to end design",
  },
  {
    id: "pm",
    label: "Project Lead",
    subtitle: "Delivery and value",
  },
  {
    id: "security",
    label: "Security Lead",
    subtitle: "Zero trust lens",
  },
];

function createReply(prompt: string, persona: PersonaId): string {
  const lower = prompt.toLowerCase();

  if (lower.includes("interview")) {
    return (
      "Here is a simple structure you can use in an interview.\n\n" +
      "1. Start from the customer or scenario.\n" +
      "2. Explain how you would understand the requirements.\n" +
      "3. Sketch a small solution in layers.\n" +
      "4. Mention trade offs and how you would learn and iterate."
    );
  }

  if (lower.includes("portfolio") || lower.includes("github")) {
    return (
      "For a portfolio, highlight a few focused projects instead of many small ones.\n\n" +
      "- One project that shows cloud thinking.\n" +
      "- One project that shows AI or data.\n" +
      "- One project that shows good UX and attention to detail.\n\n" +
      "Keep the readme files short, visual and honest."
    );
  }

  if (lower.includes("azure") || lower.includes("architecture") || lower.includes("solution")) {
    if (persona === "solution") {
      return (
        "Keep the story simple. Start from the customer goal, then describe: application layer, data layer, AI layer and security.\n\n" +
        "We can then adjust the services based on scale, cost and integration needs."
      );
    }
    if (persona === "architect") {
      return (
        "From an architecture perspective, focus on clear boundaries and observability.\n\n" +
        "Keep one or two core services at the centre, then layer security, identity and monitoring around them."
      );
    }
    if (persona === "pm") {
      return (
        "You can turn this into a small delivery plan.\n\n" +
        "Phase 1: smallest useful version.\n" +
        "Phase 2: integration and automation.\n" +
        "Phase 3: optimisation based on usage and feedback."
      );
    }
    return (
      "Looking at this with a security lens, start with identity, access and data protection.\n\n" +
      "Make sure logging is in place so you can see what is happening and react early."
    );
  }

  return (
    "I can help you think through cloud ideas, projects or interviews.\n\n" +
    "Try asking for an Azure architecture, a simple project plan or how to explain one of your projects in an interview."
  );
}

function createArchitecture(prompt: string): ArchitectureView | null {
  const lower = prompt.toLowerCase();
  const isArchitectureQuestion =
    lower.includes("azure") ||
    lower.includes("architecture") ||
    lower.includes("design") ||
    lower.includes("solution");

  if (!isArchitectureQuestion) return null;

  let scenario: string;

  if (lower.includes("retail")) {
    scenario = "Retail web application focused on cost optimisation.";
  } else if (lower.includes("health") || lower.includes("care")) {
    scenario = "Healthcare solution with higher security and compliance needs.";
  } else if (lower.includes("education") || lower.includes("student")) {
    scenario = "Education platform for students and course content.";
  } else {
    scenario = "Generic web application that needs a clean, evolvable Azure design.";
  }

  const layers: ArchitectureLayer[] = [
    {
      name: "App layer",
      services: "Azure App Service or Azure Kubernetes Service",
      notes:
        "Expose APIs and web UI. Start with managed services, move to containers if you need more control.",
    },
    {
      name: "Data layer",
      services: "Azure SQL Database or Azure Cosmos DB",
      notes:
        "Use SQL for structured transactional data. Use Cosmos DB for very large scale or global distribution.",
    },
    {
      name: "AI layer",
      services: "Azure OpenAI Service",
      notes:
        "Add copilots, chat and summarisation on top of documents, logs or tickets. Start with one focused use case.",
    },
    {
      name: "Security & identity",
      services: "Microsoft Entra ID, Azure Key Vault, Defender for Cloud",
      notes:
        "Centralise identity, keep secrets in Key Vault, and let Defender highlight misconfigurations and risks.",
    },
    {
      name: "Observability",
      services: "Azure Monitor, Application Insights, Log Analytics",
      notes:
        "Collect metrics and traces early so you can understand behaviour and diagnose issues quickly.",
    },
  ];

  return {
    title: "Azure reference sketch",
    scenario,
    layers,
  };
}



const DaniaAvatar: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: 0.3 }}
      style={{
        marginTop: 14,
        marginBottom: 6,
        padding: "14px 16px",
        borderRadius: 22,
        background:
          "linear-gradient(135deg, rgba(15,23,42,0.98), rgba(15,23,42,0.94))",
        boxShadow: "0 18px 40px rgba(15,23,42,0.9)",
        border: "1px solid rgba(148,163,184,0.4)",
        display: "flex",
        alignItems: "center",
        gap: 16,
      }}
    >
      <div
        style={{
          position: "relative",
          width: 64,
          height: 64,
          borderRadius: "999px",
          background:
            "radial-gradient(circle at 30% 15%, #fefce8, #facc15)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
        }}
      >
        {/* hair */}
        <div
          style={{
            position: "absolute",
            top: -4,
            left: 6,
            right: 6,
            height: 34,
            borderRadius: "999px",
            background:
              "linear-gradient(135deg, #f97316, #b45309)",
          }}
        />
        {/* face */}
        <div
          style={{
            position: "absolute",
            top: 8,
            left: 8,
            right: 8,
            bottom: 10,
            borderRadius: "999px",
            background:
              "radial-gradient(circle at 30% 20%, #fefce8, #facc15)",
          }}
        />
        {/* eyes */}
        <div
          style={{
            position: "absolute",
            top: 26,
            left: 21,
            width: 6,
            height: 6,
            borderRadius: "999px",
            backgroundColor: "#111827",
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 26,
            right: 21,
            width: 6,
            height: 6,
            borderRadius: "999px",
            backgroundColor: "#111827",
          }}
        />
        {/* mouth */}
        <div
          style={{
            position: "absolute",
            bottom: 18,
            left: 22,
            right: 22,
            height: 8,
            borderRadius: "999px",
            background:
              "radial-gradient(circle at 50% 0%, #f97316, #b45309)",
          }}
        />
        {/* little hand (static to avoid extra motion nesting) */}
        <div
          style={{
            position: "absolute",
            right: -4,
            bottom: 16,
            width: 18,
            height: 26,
            borderRadius: "999px",
            background:
              "linear-gradient(135deg, #fed7aa, #f97316)",
          }}
        />
      </div>
      <div style={{ maxWidth: 240 }}>
        <p
          style={{
            fontSize: 14,
            fontWeight: 600,
            marginBottom: 4,
          }}
        >
          Hi, I am Dania.
        </p>
        <p
          style={{
            fontSize: 11,
            color: "#9ca3af",
          }}
        >
          Ask me about Azure ideas, projects or interviews and I will keep things clear and calm.
        </p>
      </div>
    </motion.div>
  );
};
const App: React.FC = () => {
  const [persona, setPersona] = React.useState<PersonaId>("solution");
  const [activeTab, setActiveTab] = React.useState<TabId>("conversations");
  const [messages, setMessages] = React.useState<Message[]>([

    {
      id: 1,
      role: "assistant",
      content:
        "Hi, I am a Copilot style assistant. Ask about Azure architectures, projects or interviews and I will respond in a calm, structured way.",
    },
  ]);
  const [input, setInput] = React.useState("");
  const [isSending, setIsSending] = React.useState(false);
  const [architecture, setArchitecture] = React.useState<ArchitectureView | null>(
    null
  );
  const [showDemoNote, setShowDemoNote] = React.useState(false);
  const chatRef = React.useRef<HTMLDivElement | null>(null);
  const nextId = React.useRef(2);

  React.useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages.length]);

  const handleSubmit: React.FormEventHandler = (event) => {
    event.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isSending) return;

    setIsSending(true);

    const userMessage: Message = {
      id: nextId.current++,
      role: "user",
      content: trimmed,
    };

    const replyText = createReply(trimmed, persona);
    const arch = createArchitecture(trimmed);

    const assistantMessage: Message = {
      id: nextId.current++,
      role: "assistant",
      content: "",
    };

    setMessages((current) => [...current, userMessage, assistantMessage]);
    if (arch) {
      setArchitecture(arch);
    } else {
      setArchitecture(null);
    }

    let index = 0;
    const interval = setInterval(() => {
      index += 1;
      setMessages((current) =>
        current.map((m) =>
          m.id === assistantMessage.id
            ? { ...m, content: replyText.slice(0, index) }
            : m
        )
      );
      if (index >= replyText.length) {
        clearInterval(interval);
        setIsSending(false);
      }
    }, 12);

    setInput("");
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        margin: 0,
        background:
          "radial-gradient(circle at top, #050816 0, #020617 45%, #020617 100%)",
        color: "white",
        fontFamily:
          "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        display: "flex",
        alignItems: "stretch",
        justifyContent: "center",
        padding: "32px 16px",
        boxSizing: "border-box",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 1320,
          display: "grid",
          gridTemplateColumns: "220px minmax(0, 1.6fr) minmax(0, 1.2fr)",
          gap: 20,
        }}
      >
        {/* Sidebar */}
<motion.aside
  initial={{ opacity: 0, x: -20 }}
  animate={{ opacity: 1, x: 0 }}
  transition={{ duration: 0.6 }}
  style={{
    borderRadius: 22,
    padding: 14,
    background:
      "linear-gradient(145deg, rgba(15,23,42,0.98), rgba(15,23,42,0.96))",
    boxShadow:
      "0 24px 60px rgba(15,23,42,0.9), 0 0 0 1px rgba(31,41,55,0.9)",
    display: "flex",
    flexDirection: "column",
    gap: 14,
  }}
>
  <div
    style={{
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "4px 6px 10px",
      borderBottom: "1px solid rgba(55,65,81,1)",
    }}
  >
    <div
      style={{
        width: 22,
        height: 22,
        borderRadius: "999px",
        background:
          "radial-gradient(circle at 30% 20%, #fef9c3, #f97316)",
      }}
    />
    <div>
      <p style={{ fontSize: 13, fontWeight: 600 }}>Copilot workspace</p>
      <p style={{ fontSize: 11, color: "#9ca3af" }}>Personal demo</p>
    </div>
  </div>

  <DaniaAvatar />

  <div style={{ display: "grid", gap: 6, marginTop: 4 }}>
    <button
      type="button"
      onClick={() => setActiveTab("conversations")}
      style={{
        borderRadius: 999,
        padding: "7px 10px",
        border: "none",
        background:
          activeTab === "conversations"
            ? "linear-gradient(135deg, #111827, #020617)"
            : "transparent",
        color: activeTab === "conversations" ? "#e5e7eb" : "#9ca3af",
        fontSize: 12,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        cursor: "pointer",
      }}
    >
      <span>Conversations</span>
      {activeTab === "conversations" && (
        <span
          style={{
            fontSize: 10,
            padding: "2px 6px",
            borderRadius: 999,
            backgroundColor: "rgba(15,23,42,0.9)",
          }}
        >
          Active
        </span>
      )}
    </button>

    <button
      type="button"
      onClick={() => setActiveTab("usecases")}
      style={{
        borderRadius: 999,
        padding: "7px 10px",
        border: "none",
        background:
          activeTab === "usecases" ? "rgba(17,24,39,0.96)" : "transparent",
        color: activeTab === "usecases" ? "#e5e7eb" : "#9ca3af",
        fontSize: 12,
        textAlign: "left",
        cursor: "pointer",
      }}
    >
      Use cases
    </button>

    <button
      type="button"
      onClick={() => setActiveTab("architectures")}
      style={{
        borderRadius: 999,
        padding: "7px 10px",
        border: "none",
        background:
          activeTab === "architectures"
            ? "rgba(17,24,39,0.96)"
            : "transparent",
        color: activeTab === "architectures" ? "#e5e7eb" : "#9ca3af",
        fontSize: 12,
        textAlign: "left",
        cursor: "pointer",
      }}
    >
      Architectures
    </button>

    <button
      type="button"
      onClick={() => setActiveTab("playground")}
      style={{
        borderRadius: 999,
        padding: "7px 10px",
        border: "none",
        background:
          activeTab === "playground" ? "rgba(17,24,39,0.96)" : "transparent",
        color: activeTab === "playground" ? "#e5e7eb" : "#9ca3af",
        fontSize: 12,
        textAlign: "left",
        cursor: "pointer",
      }}
    >
      Playground
    </button>
  </div>

  <div
    style={{
      marginTop: "auto",
      fontSize: 11,
      color: "#9ca3af",
      borderTop: "1px solid rgba(55,65,81,1)",
      paddingTop: 10,
    }}
  >
    <p>Current mode: {personas.find((p) => p.id === persona)?.label}</p>
    <p style={{ opacity: 0.8 }}>
      {personas.find((p) => p.id === persona)?.subtitle}
    </p>
  </div>
</motion.aside>


        {/* Center: chat */}
        <div style={{ position: "relative" }}>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            style={{
              marginBottom: 10,
              padding: "4px 2px 18px",
            }}
          >
            <p
              style={{
                fontSize: 11,
                textTransform: "uppercase",
                letterSpacing: 3,
                color: "#9ca3af",
                marginBottom: 4,
              }}
            >
              Copilot style workspace
            </p>
            <h1
              style={{
                fontSize: 24,
                fontWeight: 600,
                marginBottom: 4,
              }}
            >
              Conversations, architectures and next steps in one place.
            </h1>
            <p
              style={{
                fontSize: 13,
                color: "#d1d5db",
                maxWidth: 520,
              }}
            >
              
              {tabMeta[activeTab].description}

            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            style={{
              borderRadius: 24,
              padding: 16,
              background:
                "linear-gradient(145deg, rgba(15,23,42,0.98), rgba(12,16,30,0.98))",
              boxShadow:
                "0 26px 70px rgba(15,23,42,1), 0 0 0 1px rgba(31,41,55,0.9)",
              display: "flex",
              flexDirection: "column",
              height: 520,
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 10,
                paddingBottom: 8,
                borderBottom: "1px solid rgba(55,65,81,1)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
    
<div
  style={{
    position: "relative",
    width: 28,
    height: 28,
    borderRadius: "999px",
    background:
      "radial-gradient(circle at 30% 15%, #fefce8, #facc15)",
    overflow: "hidden",
  }}
>
  {/* hair */}
  <div
    style={{
      position: "absolute",
      top: -2,
      left: 4,
      right: 4,
      height: 18,
      borderRadius: "999px",
      background:
        "linear-gradient(135deg, #f97316, #b45309)",
    }}
  />
  {/* face */}
  <div
    style={{
      position: "absolute",
      top: 4,
      left: 4,
      right: 4,
      bottom: 4,
      borderRadius: "999px",
      background:
        "radial-gradient(circle at 30% 20%, #fefce8, #facc15)",
    }}
  />
  {/* eyes */}
  <div
    style={{
      position: "absolute",
      top: 11,
      left: 10,
      width: 4,
      height: 4,
      borderRadius: "999px",
      backgroundColor: "#111827",
    }}
  />
  <div
    style={{
      position: "absolute",
      top: 11,
      right: 10,
      width: 4,
      height: 4,
      borderRadius: "999px",
      backgroundColor: "#111827",
    }}
  />
  {/* mouth */}
  <div
    style={{
      position: "absolute",
      bottom: 7,
      left: 10,
      right: 10,
      height: 5,
      borderRadius: "999px",
      background:
        "radial-gradient(circle at 50% 0%, #f97316, #b45309)",
    }}
  />
</div>

                <div>
                  <p style={{ fontSize: 13, fontWeight: 500 }}>Dania · Assistant</p>
                  <p style={{ fontSize: 11, color: "#9ca3af" }}>
                    {personas.find((p) => p.id === persona)?.label}
                  </p>
                </div>
              </div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  fontSize: 11,
                  color: "#9ca3af",
                }}
              >
                <span
                  style={{
                    width: 7,
                    height: 7,
                    borderRadius: 999,
                    backgroundColor: isSending ? "#facc15" : "#22c55e",
                  }}
                />
                <span>{isSending ? "Thinking" : "Ready"}</span>
              </div>
            </div>

            <div
              ref={chatRef}
              style={{
                flex: 1,
                overflowY: "auto",
                padding: "4px 4px 8px",
                display: "grid",
                gap: 8,
              }}
            >
              {messages.map((message) => (
                <div
                  key={message.id}
                  style={{
                    display: "flex",
                    justifyContent:
                      message.role === "user" ? "flex-end" : "flex-start",
                  }}
                >
                  <div
                    style={{
                      maxWidth: "85%",
                      padding: "8px 11px",
                      borderRadius:
                        message.role === "user"
                          ? "14px 14px 4px 14px"
                          : "14px 14px 14px 4px",
                      background:
                        message.role === "user"
                          ? "linear-gradient(135deg, #a855f7, #ec4899)"
                          : "rgba(17,24,39,0.98)",
                      border:
                        message.role === "user"
                          ? "1px solid rgba(191,219,254,0.9)"
                          : "1px solid rgba(55,65,81,1)",
                      fontSize: 13,
                      color: "#e5e7eb",
                      whiteSpace: "pre-wrap",
                    }}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
            </div>

            <form
              onSubmit={handleSubmit}
              style={{
                marginTop: 8,
                paddingTop: 8,
                borderTop: "1px solid rgba(55,65,81,1)",
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              <div
                style={{
                  display: "flex",
                  gap: 6,
                  flexWrap: "wrap",
                }}
              >
                {personas.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPersona(p.id)}
                    style={{
                      borderRadius: 999,
                      padding: "4px 9px",
                      border:
                        p.id === persona
                          ? "1px solid rgba(249,115,22,0.9)"
                          : "1px solid rgba(55,65,81,1)",
                      background:
                        p.id === persona
                          ? "rgba(249,115,22,0.14)"
                          : "rgba(17,24,39,0.96)",
                      color: "#e5e7eb",
                      fontSize: 11,
                      cursor: "pointer",
                    }}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                }}
              >
                <input
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  placeholder={tabMeta[activeTab].placeholder}
                  style={{
                    flex: 1,
                    borderRadius: 999,
                    border: "1px solid rgba(55,65,81,1)",
                    background: "rgba(17,24,39,0.98)",
                    padding: "9px 12px",
                    fontSize: 13,
                    color: "#e5e7eb",
                    outline: "none",
                  }}
                />
                <button
                  type="submit"
                  disabled={isSending || !input.trim()}
                  style={{
                    borderRadius: 999,
                    padding: "8px 14px",
                    border: "none",
                    fontSize: 13,
                    cursor:
                      isSending || !input.trim() ? "not-allowed" : "pointer",
                    background:
                      isSending || !input.trim()
                        ? "rgba(79,70,229,0.6)"
                        : "linear-gradient(135deg, #a855f7, #ec4899)",
                    color: "#eff6ff",
                    boxShadow:
                      "0 10px 30px rgba(168,85,247,0.7)",
                  }}
                >
                  {isSending ? "Thinking" : "Send"}
                </button>
              </div>
            </form>
          </motion.div>
        </div>

        {/* Right: architecture panel */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7 }}
          style={{
            borderRadius: 24,
            padding: 16,
            background:
              "linear-gradient(145deg, rgba(15,23,42,0.98), rgba(12,16,30,0.98))",
            boxShadow:
              "0 24px 60px rgba(15,23,42,0.9), 0 0 0 1px rgba(31,41,55,0.9)",
            display: "flex",
            flexDirection: "column",
            position: "relative",
          }}
        >
          <p
            style={{
              fontSize: 11,
              textTransform: "uppercase",
              letterSpacing: 3,
              color: "#9ca3af",
              marginBottom: 4,
            }}
          >
            Neural view · Azure sketch
          </p>
          <h2
            style={{
              fontSize: 18,
              marginBottom: 6,
            }}
          >
            {architecture ? architecture.title : "Ask for an architecture"}
          </h2>
          <p
            style={{
              fontSize: 12,
              color: "#d1d5db",
              marginBottom: 12,
            }}
          >
            {architecture
              ? architecture.scenario
              : "When your question mentions Azure or architecture, this panel will render a small reference design that you can use as a talking point."}
          </p>

          <div
            style={{
              display: "grid",
              gap: 10,
              marginBottom: 12,
            }}
          >
            {architecture ? (
              architecture.layers.map((layer) => (
                <div
                  key={layer.name}
                  style={{
                    borderRadius: 14,
                    padding: 10,
                    background: "rgba(17,24,39,0.98)",
                    border: "1px solid rgba(75,85,99,1)",
                  }}
                >
                  <p
                    style={{
                      fontSize: 12,
                      textTransform: "uppercase",
                      letterSpacing: 2,
                      color: "#f9a8d4",
                      marginBottom: 2,
                    }}
                  >
                    {layer.name}
                  </p>
                  <p
                    style={{
                      fontSize: 12,
                      color: "#e5e7eb",
                      marginBottom: 2,
                    }}
                  >
                    {layer.services}
                  </p>
                  <p
                    style={{
                      fontSize: 11,
                      color: "#9ca3af",
                    }}
                  >
                    {layer.notes}
                  </p>
                </div>
              ))
            ) : (
              <div
                style={{
                  borderRadius: 14,
                  padding: 10,
                  background: "rgba(17,24,39,0.98)",
                  border: "1px dashed rgba(75,85,99,1)",
                  fontSize: 12,
                  color: "#d1d5db",
                }}
              >
                Try: “Design an Azure architecture for a retail app that needs cost
                optimisation” or “Sketch a healthcare solution on Azure”.
              </div>
            )}
          </div>

<div
  style={{
    fontSize: 11,
    color: "#9ca3af",
    borderTop: "1px solid rgba(55,65,81,1)",
    paddingTop: 8,
    display: "flex",
    flexDirection: "column",
    gap: 8,
  }}
>
  <span>
    • Use this view as a starting point, not as a final design.
  </span>
  <span>
    • The goal is to show how you think in layers, trade offs and customer scenarios.
  </span>

  <div
    style={{
      marginTop: 8,
      maxWidth: 360,
      padding: "10px 14px",
      borderRadius: 999,
      background:
        "linear-gradient(135deg, rgba(24,24,27,0.95), rgba(76,29,149,0.9))",
      border: "1px solid rgba(148,163,184,0.7)",
      fontSize: 11,
      color: "#e5e7eb",
      display: "flex",
      alignItems: "center",
      gap: 10,
    }}
  >
    <div
      style={{
        width: 26,
        height: 26,
        borderRadius: "999px",
        background:
          "radial-gradient(circle at 30% 20%, #fef3c7, #f97316)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 16,
      }}
    >
      💡
    </div>
    <div>
      <p
        style={{
          fontWeight: 500,
          marginBottom: 2,
        }}
      >
        Pro tip
      </p>
      <p>
        Try asking for an Azure architecture for a specific app or
        customer scenario on the left. This panel will sketch a
        simple reference design you can use in a conversation.
      </p>
    </div>
  </div>
</div>


          <button
            type="button"
            onClick={() => setShowDemoNote((value) => !value)}
            style={{
              position: "absolute",
              bottom: 14,
              right: 16,
              borderRadius: 999,
              padding: "4px 10px",
              border: "1px solid rgba(75,85,99,1)",
              background: "rgba(15,23,42,0.96)",
              color: "#e5e7eb",
              fontSize: 11,
              cursor: "pointer",
            }}
          >
            About this demo
          </button>

          {showDemoNote && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              style={{
                position: "absolute",
                bottom: 46,
                right: 16,
                maxWidth: 260,
                padding: "10px 12px",
                borderRadius: 14,
                background: "rgba(15,23,42,0.98)",
                border: "1px solid rgba(75,85,99,1)",
                fontSize: 11,
                color: "#e5e7eb",
                boxShadow: "0 18px 40px rgba(15,23,42,0.9)",
              }}
            >
              <p style={{ marginBottom: 2 }}>
                Thank you for taking the time to look at this workspace.
              </p>
              <p>
                It is a small demo to show how I think about Azure layers, customer
                scenarios and structured communication, not just the code itself.
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default App;
