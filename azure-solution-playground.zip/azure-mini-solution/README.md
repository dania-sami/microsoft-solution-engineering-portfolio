# Azure Solution Playground

This is a hero portfolio project designed specifically to support applications for the Microsoft Solution Engineering Internship.

It is a small but high impact web app where a user selects an **industry** and a **business priority** and the interface:

1. Generates a **clear Azure architecture narrative** you could use directly in a customer meeting.
2. Shows a **3D style animated Azure map** made with CSS 3D transforms and Framer Motion.
3. Demonstrates that you can connect **business needs** to **concrete Azure services**.

## Tech stack

- React 18
- TypeScript
- Vite
- Framer Motion for rich, smooth 3D like animations

## How this helps you stand out for Microsoft

You can talk about this project in your CV, LinkedIn and interview as:

> Built an interactive Azure architecture playground that maps customer industry and priorities to a narrative and visual 3D solution diagram, showcasing how I think like a Microsoft Solution Engineer.

It proves:

- You understand basic Azure services and how they fit together.
- You can think in terms of **customer industry + priority** instead of just raw technology.
- You can create **demo ready assets** that sales and technical teams can use with customers.

## How to run locally

```bash
npm install
npm run dev
```

Then open the printed local URL in your browser.

## Suggested next step

Deploy this app to **Azure App Service** and mention in your CV:

> Deployed the Azure Solution Playground to Azure App Service as a live demo environment for stakeholder meetings.
